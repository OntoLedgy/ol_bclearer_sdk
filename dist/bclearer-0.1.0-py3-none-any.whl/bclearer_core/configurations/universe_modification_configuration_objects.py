
class UniverseModificationConfigurationObjects:
    pass

