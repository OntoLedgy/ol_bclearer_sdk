from nf_ea_common_tools_source.b_code.services.general.nf_ea.com.common_knowledge.collection_types.nf_ea_com_collection_types import NfEaComCollectionTypes

LIST_OF_COLLECTION_TYPES_OF_OBJECTS_WITHOUT_EA_GUIDS = [
    NfEaComCollectionTypes.EA_CARDINALITIES,
    NfEaComCollectionTypes.EA_CONNECTOR_TYPES,
    NfEaComCollectionTypes.EA_DIAGRAM_TYPES,
    NfEaComCollectionTypes.EA_ELEMENT_TYPES
]
