NAME_INSTANCE_ATTRIBUTE_NAME = \
    'name_instance'

NAME_EXEMPLAR_ATTRIBUTE_NAME = \
    'name_exemplar'
