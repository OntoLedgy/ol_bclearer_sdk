import pandas
from nf_common.code.services.bclearer_load_service.common.output_folder_creator import create_output_folder
from bclearer_interop_services.file_system_service.objects.folders import Folders
from nf_common.code.services.bclearer_load_service.common_knowledge.bclearer_load_constants import \
    SUMMARY_OUTPUT_TABLE_NAME
from bclearer_interop_services.delimited_text import \
    write_dataframe_to_csv_file


def report_summary_table(
        output_root_folder: Folders,
        summary_dataframe: pandas.DataFrame,
        run_suffix: str) \
        -> None:
    output_folder_path = \
        create_output_folder(
            output_root_folder=output_root_folder,
            run_suffix=run_suffix)

    write_dataframe_to_csv_file(
        folder_name=output_folder_path,
        dataframe_name=SUMMARY_OUTPUT_TABLE_NAME,
        dataframe=summary_dataframe)
