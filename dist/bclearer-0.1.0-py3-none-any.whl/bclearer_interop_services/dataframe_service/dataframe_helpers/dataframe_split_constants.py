EQUAL_ROWS_DATAFRAME_NAME = \
    'dataframe_of_equal_rows'

NON_EQUAL_ROWS_DATAFRAME_NAME = \
    'dataframe_of_non_equal_rows'
