DATA = "load_files"

QUERIES = "queries"