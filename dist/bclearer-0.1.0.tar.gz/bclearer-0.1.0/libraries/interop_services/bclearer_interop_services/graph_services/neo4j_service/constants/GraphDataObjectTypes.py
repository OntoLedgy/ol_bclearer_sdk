from enum import Enum

class GraphObjectTypes(Enum):
    NODES = 1
    EDGES = 2       
    