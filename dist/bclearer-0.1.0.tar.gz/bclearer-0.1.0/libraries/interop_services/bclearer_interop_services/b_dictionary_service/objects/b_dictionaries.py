class BDictionaries:
    def __init__(
            self):
        self.dictionary = \
            dict()
