class BEngProjectFolderLists:

    def __init__(
            self,
            list_items: list):
        self.list = \
            list_items
