from enum import auto
from enum import Enum


class EnvironmentLogLevelTypes(
        Enum):
    NOT_SET = \
        auto()

    NONE = \
        auto()

    FULL = \
        auto()

    FILTERED = \
        auto()
