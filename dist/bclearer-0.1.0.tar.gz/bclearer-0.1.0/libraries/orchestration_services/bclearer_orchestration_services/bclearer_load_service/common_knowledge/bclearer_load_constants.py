IDENTITY_HASHES_CONFIGURATION_NAME = \
    'identity_hashes'

ALTERNATIVE_IDENTITY_HASHES_CONFIGURATION_NAME = \
    'alternative_identity_hashes'

CORE_CONTENT_HASHES_CONFIGURATION_NAME = \
    'core_content_hashes'

CONTENT_HASHES_CONFIGURATION_NAME = \
    'content_hashes'

COLUMNS_IN_SCOPE_CONFIGURATION_NAME = \
    'columns_in_scope'

IDENTITY_HASH_SET_CONTENT_HASH_NAME = \
    'identity_hash_set_content_hashes'

ALTERNATIVE_IDENTITY_HASH_SET_CONTENT_HASH_NAME = \
    'alternative_identity_hash_set_content_hashes'

CORE_CONTENT_SET_CONTENT_HASH_NAME = \
    'core_content_hash_set_content_hashes'

CONTENT_HASH_SET_CONTENT_HASH_NAME = \
    'content_hash_set_content_hashes'

HASHIFIED_OUTPUT_TABLE_NAME = \
    'hashified_table'

SUMMARY_OUTPUT_TABLE_NAME = \
    'summary_hash_table'

KEY_NAMES_CONFIGURATION_COLUMN_NAME = \
    'key_names'

VALUES_CONFIGURATION_COLUMN_NAME = \
    'values'

NAMES_SUMMARY_COLUMN_NAME = \
    'names'

HASHES_SUMMARY_COLUMN_NAME = \
    'hashes'
