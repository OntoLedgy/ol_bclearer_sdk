class BIdentityRegistries:
    def __init__(
            self,
            owning_b_identity_universe):
        self.owning_b_identity_universe = \
            owning_b_identity_universe

        self.table_dictionary = \
            dict()
