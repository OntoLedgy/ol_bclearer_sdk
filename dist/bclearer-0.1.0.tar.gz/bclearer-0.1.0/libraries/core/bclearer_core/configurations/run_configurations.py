class RunConfigurations:
    hdf5_output = \
        False

    csv_output = \
        True
