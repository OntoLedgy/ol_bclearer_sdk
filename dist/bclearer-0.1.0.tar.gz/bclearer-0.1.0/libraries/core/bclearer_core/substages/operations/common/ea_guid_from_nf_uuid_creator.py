def create_ea_guid_from_nf_uuid(
        nf_uuid: str) \
        -> str:
    ea_guid = \
        '{' + nf_uuid + '}'

    return \
        ea_guid
